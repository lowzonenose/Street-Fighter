from cx_Freeze import setup, Executable


setup(
	name = "NOM",
	version = "0.1",
	description = "",
	executables = [Executable("game.py", base = "Win32GUI")]
)